from shop import db

from datetime import datetime


class Product(db.Model):
    id = db.Column(db.Integer, primary_key=True)
    name = db.Column(db.String, nullable=False)
    description = db.Column(db.Text, nullable=False)
    price=db.Column(db.Numeric(10,2),nullable=False)
    stock=db.Column(db.Integer,nullable=False)
    pub_date = db.Column(db.DateTime, nullable=False,
        default=datetime.utcnow)

    brand_id = db.Column(db.Integer, db.ForeignKey('brand.id'),
        nullable=False)
    brand = db.relationship('Brand',
        backref=db.backref('brands', lazy=True))

    image1=db.Column(db.String(150),nullable=False,default='image.jpg')
    image2=db.Column(db.String(150),nullable=False,default='image.jpg')
    image3=db.Column(db.String(150),nullable=False,default='image.jpg')

    category_id = db.Column(db.Integer, db.ForeignKey('category.id'),
        nullable=False)
    category = db.relationship('Category',
        backref=db.backref('posts', lazy=True))

    def __repr__(self):
        return '<Addproduct %r>' % self.name

class Brand(db.Model):
    id=db.Column(db.Integer,primary_key=True)
    name=db.Column(db.String(30),nullable=False,unique=True)

class Category(db.Model):
    id=db.Column(db.Integer,primary_key=True)
    name=db.Column(db.String(30),nullable=False,unique=True)

class Cart(db.Model):
    id = db.Column(db.Integer, primary_key=True)
    quantity=db.Column(db.Integer,nullable=False)
    total=db.Column(db.Integer, nullable=False)
    session_id=db.Column(db.Integer,nullable=False)
    product_id=db.Column(db.Integer,nullable=False)

class Order(db.Model):
    id = db.Column(db.Integer, primary_key=True)
    name=db.Column(db.String(30),nullable=False)
    address=db.Column(db.String(30),nullable=False)
    city=db.Column(db.String(30),nullable=False)
    pincode=db.Column(db.Integer,nullable=False)
    totalprice=db.Column(db.Integer,nullable=False)
    phone = db.Column(db.Integer,nullable=False)

class OrderDetails(db.Model):
    id = db.Column(db.Integer, primary_key=True)
    order_id = db.Column(db.Integer, db.ForeignKey('order.id'))
    product_id=db.Column(db.Integer,nullable=False)
    quantity=db.Column(db.Integer,nullable=False)



db.create_all()
from flask import redirect,render_template,url_for,flash,request
from shop import db,app,photos
from .models import Brand,Category,Product,Order,Cart,OrderDetails
from .forms import PlaceOrder
import secrets

#product landing page
@app.route('/')
def home():
    count=Cart.query.filter_by(session_id=1).count()
    products=Product.query.all()
    brands=Brand.query.join(Product,(Brand.id==Product.brand_id)).all()
    categories=Category.query.join(Product,(Category.id==Product.category_id)).all()
    return render_template('products/index.html',title='Home',products=products,brands=brands,categories=categories,count=count)



#filter by brands
@app.route('/brand/<int:id>')
def get_brand(id):
    count=Cart.query.filter_by(session_id=1).count()
    brand=Product.query.filter_by(brand_id=id)
    brands=Brand.query.join(Product,(Brand.id==Product.brand_id)).all()
    categories=Category.query.join(Product,(Category.id==Product.category_id)).all()
    return render_template('products/index.html',title='Home',brands=brands,brand=brand,categories=categories,count=count)

#filter by categories
@app.route('/category/<int:id>')
def get_category(id):
    count=Cart.query.filter_by(session_id=1).count()
    brands=Brand.query.join(Product,(Brand.id==Product.brand_id)).all()
    get_pro=Product.query.filter_by(category_id=id)
    categories=Category.query.join(Product,(Category.id==Product.category_id)).all()
    return render_template('products/index.html',title='Home',get_pro=get_pro,categories=categories,brands=brands,count=count)

#product details page
@app.route('/product/<int:id>')
def product_details(id):
    count=Cart.query.filter_by(session_id=1).count()
    brands=Brand.query.join(Product,(Brand.id==Product.brand_id)).all()
    categories=Category.query.join(Product,(Category.id==Product.category_id)).all()
    product=Product.query.get_or_404(id)
    brand=Brand.query.all()
    return render_template('products/products-detail.html',title='Home',product=product,brand=brand,brands=brands,categories=categories,count=count)


#checkout page
@app.route('/checkout',methods=['POST','GET'])
def checkout():
    count=Cart.query.filter_by(session_id=1).count()
    brands=Brand.query.join(Product,(Brand.id==Product.brand_id)).all()
    categories=Category.query.join(Product,(Category.id==Product.category_id)).all()
    form=PlaceOrder(request.form)
    if request.method=='POST':
        name=form.cname.data
        address=form.address.data
        city=form.city.data
        phone=form.phone.data
        pincode=form.pincode.data

        allProducts = Cart.query.filter_by(session_id=1).all()
        producttotal = []
        quantity=[]
        product_id=[]
        total=0
        for prd in allProducts:
            producttotal.append(prd.total)
        for i in producttotal:
            total+=i
        
        order=Order(name=name,address=address,city=city,phone=phone,
        pincode=pincode,totalprice=total)
        db.session.add(order)
        db.session.commit()

        for prd in allProducts:
            orderdetails=OrderDetails(order_id=order.id,product_id=prd.product_id,quantity=prd.quantity)
            db.session.add(orderdetails)
            db.session.delete(prd)
            db.session.commit()

        
        db.session.commit()
        
        flash(f'Order has been placed successfully','success')
        return redirect(url_for('home'))
    return render_template('products/checkout.html',title='checkout',form=form,count=count,brands=brands,categories=categories)


from flask_wtf.file import FileAllowed,FileField,FileRequired
from wtforms import Form ,IntegerField,StringField,BooleanField,TextAreaField,validators


class PlaceOrder(Form):
    cname=StringField('Customer Name',[validators.DataRequired()])
    address=StringField('Address',[validators.DataRequired()])
    city=StringField('City',[validators.DataRequired()])
    pincode=IntegerField('Pincode',[validators.DataRequired()])
    phone=IntegerField('Phone No.',[validators.DataRequired()])



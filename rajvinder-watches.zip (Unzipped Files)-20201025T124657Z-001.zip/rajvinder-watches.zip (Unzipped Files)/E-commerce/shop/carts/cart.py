from flask import redirect,session,render_template,request,url_for,flash
from shop import app,db
from shop.products.models import Product,Cart,Brand,Category
from flask import jsonify


#adds item to cart
@app.route('/addcart',methods=['POST'])
def AddCart():
        
        product_id=request.form.get('product_id')
        quantity=request.form.get('quantity')
        try:
            cartitem=Cart.query.filter_by(product_id=product_id).first()
            cartitem.quantity+=int(quantity)
            price=Product.query.filter_by(id=cartitem.product_id).first().price
            cartitem.total=int(price)*int(cartitem.quantity)
            db.session.commit()
            return redirect(url_for('home'))

        except:
            product=Product.query.filter_by(id=product_id).first()
            if product_id and quantity and request.method=='POST':
                carts=Cart(quantity=quantity,total=(int(quantity)*int(product.price)),session_id=1,product_id=product_id)
                db.session.add(carts)
                db.session.commit()
                flash(f'The product has been added successfully to cart','success')
                return redirect(url_for('home'))



#gets cart items
@app.route('/carts',methods=['POST','GET'])
def getCart():
    count=Cart.query.filter_by(session_id=1).count()
    brands=Brand.query.join(Product,(Brand.id==Product.brand_id)).all()
    categories=Category.query.join(Product,(Category.id==Product.category_id)).all()
    allProducts = Cart.query.filter_by(session_id=1).all()
    productIds = []
    
    for prd in allProducts:
        productIds.append(prd.product_id)
    cart=Cart.query.all()
    
    products = []
    for pd in productIds:
        products.append(Product.query.filter_by(id=pd).first())
    return render_template('products/shopping-cart.html',cart=cart,products=products,count=count,brands=brands,categories=categories)

#Updates/Deletes cart items
@app.route('/carts/<int:id>',methods=['POST','GET'])
def update_cart(id):
    if request.method == 'POST':
        #updates cart
        if request.form.get('update_button') == 'update':
            quantity=request.form['quantity']
            cart=Cart.query.filter_by(id=id).first()
            cart.quantity=quantity
            price=Product.query.filter_by(id=cart.product_id).first().price
            cart.total=int(price)*int(cart.quantity)
            db.session.commit()
            flash('Your cart has been updated','success')
            return redirect(url_for('getCart',id=id))
            
        #deletes cart
        elif request.form.get('update_button') == 'delete':
            cart=Cart.query.filter_by(id=id).first()
            db.session.delete(cart)
            db.session.commit()	
            flash('Your cart has been deleted','success')
            return redirect(url_for('getCart'))

    return render_template('products/shopping-cart.html',title='Update Cart')
